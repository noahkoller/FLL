# First Lego League (FLL)

Web-App für die fiktive Fussball-Liga **First Lego League** mit 20 Teams.

## Funktionen
- **Tabelle** — berechnet sich automatisch aus den Ergebnissen. Farbzonen mit Legende:
  - Champions League (Platz 1–5, blau)
  - CL-Playoff (Platz 6–7, hellblau)
  - Abstiegs-Playoff (Platz 18, hellrot)
  - Abstieg (Platz 19–20, rot)
- **Spielplan** — komplette Hin- und Rückrunde (38 Spieltage, 380 Spiele) plus zwei Playoff-Spieltage am Saisonende (Hinspiel / Rückspiel), die als normale Spiele auftauchen. Spieltag-Wechsel per Pfeil ‹ ›. Ergebnisse eintragen, spielen oder simulieren — die Tabelle aktualisiert sich sofort. Playoff-Spiele zählen nicht für die Ligatabelle, aber für die Torschützen. Die Playoff-Paarungen (6. vs. 7. und 18. vs. 3. der 2. Liga) ergeben sich automatisch aus der Tabelle; den Namen des 2.-Liga-Gegners trägst du direkt beim Playoff-Spieltag ein. Auf schmalen Bildschirmen (Hochformat) werden statt der vollen Teamnamen die Kürzel neben den Logos gezeigt.
- **Torschützenliste** — wird automatisch aus allen Ergebnissen berechnet (Liga und Playoffs, simuliert wie selbst gespielt). Die Tore jedes Spiels werden auf die drei Kaderspieler des Teams verteilt; offensivere Trikotnummern treffen häufiger. Gleiche Ergebnisse ergeben immer dieselben Torschützen — die Liste ändert sich nur, wenn ein Resultat geändert wird.
- **Mini-Game** — neben jedem Spiel im Spielplan startet ein ▶-Knopf ein kleines Fussballspiel im Club-Legend-Stil: Top-down-Ansicht, Spieler als Punkte mit Trikotnummer und Name. Vor dem Anpfiff wählst du, welches der beiden Teams du selbst steuerst — das andere übernimmt der Computer. Ziehen/Tippen bewegt den aktiven Spieler, um den Ball ins Tor zu schiessen. Über **Ergebnis übernehmen** wandert der Endstand direkt in Tabelle und Spielplan (korrekt der Heim/Auswärts-Seite zugeordnet). Jedes Team hat 3 Spieler im Kader. Die Gegner-Schwierigkeit richtet sich nach der Team-Stärke (gute Teams spielen etwas stärker), bleibt aber bewusst einsteigerfreundlich.
- **Simulation** — der ⚄-Knopf neben jedem Spiel würfelt ein plausibles Ergebnis anhand der Team-Stärken (gut / mittel / underdog) plus kleinem Heimvorteil. Über **Ganzen Spieltag simulieren** lässt sich der komplette Spieltag auf einmal berechnen. Überraschungen sind eingebaut — auch ein Underdog kann mal gewinnen.

Team-Stärken: gut = FLC, BLC, GSF, VAT, SPF, NMC · mittel = RBB, FFS, NOR, SOU, UVAT, WTU, LNI, KEY · underdog = MID, PLT, NHT, FHV, FST, FCC.

Alle Eingaben werden lokal im Browser gespeichert (localStorage) und bleiben nach dem Neuladen erhalten.

## Auf GitHub Pages veröffentlichen
Die Team-Logos sind direkt in die `index.html` eingebettet — du brauchst **nur diese eine Datei** hochzuladen, sonst nichts.

1. Neues Repository auf GitHub erstellen (z. B. `fll`).
2. `index.html` ins Repository hochladen.
3. Im Repository auf **Settings → Pages** gehen.
4. Bei **Source** den Branch `main` und den Ordner `/ (root)` wählen, dann **Save**.
5. Nach kurzer Zeit ist die App unter `https://DEINNAME.github.io/fll/` erreichbar.

## Struktur
```
index.html      → die komplette App inkl. eingebetteter Logos
logos/          → Original-Logos (optional, werden nicht mehr benötigt)
```
